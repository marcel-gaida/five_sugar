package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
)

// ── Logging ──────────────────────────────────────────────────────────────────

func logFile() string {
	exe, _ := os.Executable()
	return filepath.Join(filepath.Dir(exe), "kitchenvault_host.log")
}

func logMessage(msg string) {
	f, err := os.OpenFile(logFile(), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	f.WriteString(msg + "\n")
}

// ── Native Messaging protocol ─────────────────────────────────────────────────

func readMessage() (map[string]interface{}, error) {
	var length uint32
	if err := binary.Read(os.Stdin, binary.NativeEndian, &length); err != nil {
		return nil, err
	}
	buf := make([]byte, length)
	if _, err := io.ReadFull(os.Stdin, buf); err != nil {
		return nil, err
	}
	var msg map[string]interface{}
	if err := json.Unmarshal(buf, &msg); err != nil {
		return nil, err
	}
	return msg, nil
}

func sendMessage(msg map[string]interface{}) {
	data, _ := json.Marshal(msg)
	length := uint32(len(data))
	binary.Write(os.Stdout, binary.NativeEndian, length)
	os.Stdout.Write(data)
	os.Stdout.Sync()
}

// ── Open in file manager ──────────────────────────────────────────────────────

func resolvePath(absRoot, relativeFilePath, rootFolderName string) string {
	relativeFilePath = strings.ReplaceAll(relativeFilePath, "\\", "/")
	rootFolderName = strings.ReplaceAll(rootFolderName, "\\", "/")

	relLower := strings.ToLower(relativeFilePath)
	prefixLower := strings.ToLower(rootFolderName + "/")

	var subPath string
	if strings.HasPrefix(relLower, prefixLower) {
		subPath = relativeFilePath[len(prefixLower):]
	} else if relLower == strings.ToLower(rootFolderName) {
		subPath = ""
	} else {
		subPath = relativeFilePath
	}

	return filepath.Join(absRoot, subPath)
}

func findLocatorFile(locatorName string) string {
	var roots []string

	// 1. Parents of executable
	exePath, _ := os.Executable()
	dir := filepath.Dir(exePath)
	for {
		roots = append(roots, dir)
		parent := filepath.Dir(dir)
		if parent == dir {
			break
		}
		dir = parent
	}

	// 2. Workspace
	roots = append(roots, `M:\Antigravity Workfolder`)

	// 3. User profiles
	userProfile := os.Getenv("USERPROFILE")
	if userProfile != "" {
		roots = append(roots, filepath.Join(userProfile, "Documents"))
		roots = append(roots, filepath.Join(userProfile, "Downloads"))
		roots = append(roots, filepath.Join(userProfile, "Desktop"))
		roots = append(roots, userProfile)
	}

	// 4. Drive roots on Windows
	if runtime.GOOS == "windows" {
		for _, drive := range "ABCDEFGHIJKLMNOPQRSTUVWXYZ" {
			d := string(drive) + ":\\"
			if stat, err := os.Stat(d); err == nil && stat.IsDir() {
				roots = append(roots, d)
			}
		}
	} else {
		roots = append(roots, "/")
	}

	// Remove duplicates
	seen := make(map[string]bool)
	var uniqueRoots []string
	for _, r := range roots {
		if !seen[r] {
			seen[r] = true
			uniqueRoots = append(uniqueRoots, r)
		}
	}

	logMessage(fmt.Sprintf("Starting locator search for '%s' in roots: %v", locatorName, uniqueRoots))
	for _, root := range uniqueRoots {
		found := ""
		filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
			if found != "" {
				return filepath.SkipDir
			}
			if err != nil {
				return nil
			}
			if info.IsDir() {
				name := strings.ToLower(info.Name())
				// Skip some dirs
				skip := []string{"appdata", "windows", "program files", "program files (x86)", "node_modules", ".git", "venv", ".venv", "package_cache", ".gemini", "system volume information", "$recycle.bin", "cache", "temp", "tmp"}
				for _, s := range skip {
					if name == s {
						return filepath.SkipDir
					}
				}
			} else {
				if info.Name() == locatorName {
					found = path
					return filepath.SkipDir
				}
			}
			return nil
		})
		if found != "" {
			logMessage(fmt.Sprintf("Found locator file at: %s", found))
			return found
		}
	}
	logMessage(fmt.Sprintf("Locator file '%s' NOT found in any scanned roots.", locatorName))
	return ""
}

func openPath(targetPath string) error {
	info, err := os.Stat(targetPath)
	if err != nil {
		return fmt.Errorf("path not found: %s", targetPath)
	}

	if runtime.GOOS == "windows" {
		if info.IsDir() {
			return exec.Command("explorer.exe", targetPath).Start()
		}
		return exec.Command("explorer.exe", "/select,", targetPath).Start()
	} else if runtime.GOOS == "darwin" {
		if info.IsDir() {
			return exec.Command("open", targetPath).Start()
		}
		return exec.Command("open", "-R", targetPath).Start()
	} else {
		target := targetPath
		if !info.IsDir() {
			target = filepath.Dir(targetPath)
		}
		for _, fm := range []string{"nautilus", "dolphin", "thunar", "nemo", "pcmanfm", "xdg-open"} {
			if _, err := exec.LookPath(fm); err == nil {
				return exec.Command(fm, target).Start()
			}
		}
		return fmt.Errorf("no file manager found")
	}
}

// ── Self-registration ─────────────────────────────────────────────────────────

const extensionID = "phpackaolekfekmdagndpdconkmkbpal"
const hostName = "kitchenvault_host"

func install() error {
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	exe, _ = filepath.Abs(exe)

	manifest := map[string]interface{}{
		"name":            hostName,
		"description":     "Kitchen Vault Native Host — opens files in your file manager",
		"path":            exe,
		"type":            "stdio",
		"allowed_origins": []string{"chrome-extension://" + extensionID + "/"},
	}
	data, _ := json.MarshalIndent(manifest, "", "  ")

	manifestPath, err := manifestLocation()
	if err != nil {
		return err
	}

	if err := os.MkdirAll(filepath.Dir(manifestPath), 0755); err != nil {
		return err
	}
	if err := os.WriteFile(manifestPath, data, 0644); err != nil {
		return err
	}

	if runtime.GOOS == "windows" {
		return registerWindows(manifestPath)
	}
	return nil // Mac/Linux use the manifest path directly
}

func manifestLocation() (string, error) {
	switch runtime.GOOS {
	case "windows":
		exe, _ := os.Executable()
		return filepath.Join(filepath.Dir(exe), hostName+".json"), nil
	case "darwin":
		home, _ := os.UserHomeDir()
		return filepath.Join(home, "Library", "Application Support", "Google", "Chrome",
			"NativeMessagingHosts", hostName+".json"), nil
	case "linux":
		home, _ := os.UserHomeDir()
		return filepath.Join(home, ".config", "google-chrome",
			"NativeMessagingHosts", hostName+".json"), nil
	}
	return "", fmt.Errorf("unsupported OS")
}

func registerWindows(manifestPath string) error {
	// Use reg.exe so we don't need CGO or syscall imports
	key := `HKCU\Software\Google\Chrome\NativeMessagingHosts\` + hostName
	cmd := exec.Command("reg", "add", key, "/ve", "/t", "REG_SZ", "/d", manifestPath, "/f")
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("registry error: %s — %v", strings.TrimSpace(string(out)), err)
	}
	return nil
}

func uninstall() error {
	manifestPath, err := manifestLocation()
	if err != nil {
		return err
	}
	os.Remove(manifestPath)

	if runtime.GOOS == "windows" {
		key := `HKCU\Software\Google\Chrome\NativeMessagingHosts\` + hostName
		exec.Command("reg", "delete", key, "/f").Run()
	}
	return nil
}

func getString(m map[string]interface{}, key string) string {
	if val, ok := m[key].(string); ok {
		return val
	}
	return ""
}

// ── Main ──────────────────────────────────────────────────────────────────────

func main() {
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "--install":
			if err := install(); err != nil {
				fmt.Fprintf(os.Stderr, "Install failed: %v\n", err)
				os.Exit(1)
			}
			fmt.Println("Kitchen Vault host registered successfully.")
			os.Exit(0)
		case "--uninstall":
			uninstall()
			fmt.Println("Kitchen Vault host unregistered.")
			os.Exit(0)
		case "--version":
			fmt.Println("kitchenvault_host v1.0.0")
			os.Exit(0)
		}
	}

	logMessage("Kitchen Vault host started")

	for {
		msg, err := readMessage()
		if err != nil {
			logMessage("Read error: " + err.Error())
			break
		}
		logMessage(fmt.Sprintf("Received: %v", msg))

		action := getString(msg, "action")

		switch action {
		case "open_direct":
			absRoot := getString(msg, "absolutePath")
			relativeFilePath := getString(msg, "relativePath")
			rootFolderName := getString(msg, "rootFolderName")

			targetPath := resolvePath(absRoot, relativeFilePath, rootFolderName)
			logMessage(fmt.Sprintf("Resolved path for open_direct: %s", targetPath))

			if err := openPath(targetPath); err != nil {
				sendMessage(map[string]interface{}{"status": "error", "error": err.Error()})
			} else {
				sendMessage(map[string]interface{}{"status": "success"})
			}

		case "locate_and_open":
			locatorId := getString(msg, "locatorId")
			relativeFilePath := getString(msg, "relativePath")
			rootFolderName := getString(msg, "rootFolderName")

			locatorName := fmt.Sprintf(".kv_locator_%s", locatorId)
			locatorPath := findLocatorFile(locatorName)

			if locatorPath != "" {
				os.Remove(locatorPath)
				logMessage(fmt.Sprintf("Successfully deleted locator file: %s", locatorPath))

				absRoot := filepath.Dir(locatorPath)
				targetPath := resolvePath(absRoot, relativeFilePath, rootFolderName)
				logMessage(fmt.Sprintf("Resolved path for locate_and_open: %s", targetPath))

				if err := openPath(targetPath); err != nil {
					// Fallback to containing directory or root
					containingDir := filepath.Dir(targetPath)
					if _, err := os.Stat(containingDir); err == nil {
						openPath(containingDir)
					} else {
						openPath(absRoot)
					}
					sendMessage(map[string]interface{}{"status": "success", "rootPath": absRoot, "warning": fmt.Sprintf("Target file not found at %s", targetPath)})
				} else {
					sendMessage(map[string]interface{}{"status": "success", "rootPath": absRoot})
				}
			} else {
				sendMessage(map[string]interface{}{"status": "error", "error": "Could not locate vault root folder dynamically."})
			}

		case "open_in_folder":
			path := getString(msg, "path")
			if path == "" {
				sendMessage(map[string]interface{}{"status": "error", "error": "no path provided"})
				continue
			}
			if err := openPath(path); err != nil {
				logMessage("Open error: " + err.Error())
				sendMessage(map[string]interface{}{"status": "error", "error": err.Error()})
			} else {
				sendMessage(map[string]interface{}{"status": "success"})
			}

		case "ping":
			sendMessage(map[string]interface{}{"status": "ok", "version": "1.0.0"})

		default:
			sendMessage(map[string]interface{}{"status": "error", "error": "unknown action: " + action})
		}
	}
}
